mod app_state;
mod commands;
mod models;
mod sidecar;
mod sidecar_proxy;

use std::sync::atomic::Ordering; 
use tauri::RunEvent;

use app_state::AppState;
use sidecar_proxy::SidecarProxy;

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    let state = AppState::default();
    let proxy = SidecarProxy::new().expect("Unable to initialise the local sidecar proxy.");
    let startup_state = state.clone();
    let shutdown_state = state.clone();

    let app = tauri::Builder::default()
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_shell::init())
        .manage(state.clone())
        .manage(proxy.clone())
        .setup(move |app| {
            sidecar::launch(app.handle().clone(), startup_state.clone());
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            commands::bootstrap::get_bootstrap_status,
            commands::bootstrap::get_git_installation_status,
            commands::repositories::list_repositories,
            commands::repositories::pick_and_classify_repository,
            commands::repositories::register_repository,
            commands::repositories::initialise_and_register_repository,
            commands::repositories::get_repository_snapshot,
            commands::repositories::run_read_action,
            commands::repositories::resolve_local_request,

        ])
        .build(tauri::generate_context!())
        .expect("error while building AI Git Assistant");

    app.run(move |app_handle, event| {
        if let RunEvent::ExitRequested { api, .. } = event {
            // The first exit request is the user closing the application. Pause it
            // while Rust terminates the private sidecar process tree.
            if shutdown_state
                .shutdown_started
                .swap(true, Ordering::AcqRel)
            {
                // app_handle.exit(0) triggers a second ExitRequested event after
                // cleanup. Let that final event exit normally.
                return;
            }

            api.prevent_exit();

            let state = shutdown_state.clone();
            let app_handle = app_handle.clone();

            tauri::async_runtime::spawn(async move {
                sidecar::stop_sidecar(state).await;

                // Cleanup is complete, so allow Tauri to perform its normal exit.
                app_handle.exit(0);
            });
        }
    });


}
