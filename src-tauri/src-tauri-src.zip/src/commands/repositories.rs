use serde_json::json;
use tauri::{AppHandle, State};
use tauri_plugin_dialog::{DialogExt, FilePath};

use crate::{
    app_state::AppState,
    models::repositories::{
        FolderClassification, LocalResolution, ReadActionRequest, ReadActionResult, Repository,
        RepositorySnapshot,
    },
    sidecar_proxy::SidecarProxy,
};

#[tauri::command(rename_all = "camelCase")]
pub async fn list_repositories(
    state: State<'_, AppState>,
    proxy: State<'_, SidecarProxy>,
) -> Result<Vec<Repository>, String> {
    proxy.get(&state, "/v1/repositories").await
}

#[tauri::command(rename_all = "camelCase")]
pub async fn pick_and_classify_repository(
    app: AppHandle,
    state: State<'_, AppState>,
    proxy: State<'_, SidecarProxy>,
) -> Result<Option<FolderClassification>, String> {
    let selected = app.dialog().file().blocking_pick_folder();
    let Some(selected) = selected else {
        return Ok(None);
    };

    let path = match selected {
        FilePath::Path(path) => path,
        FilePath::Url(_) => {
            return Err("The selected folder must be a local filesystem path.".to_owned());
        }
    };

    let payload = json!({ "path": path.to_string_lossy() });

    // This route only classifies the selected folder. It never registers a
    // repository, creates .git metadata, or modifies the selected folder.
    proxy
        .post(&state, "/v1/repositories/classify", &payload)
        .await
        .map(Some)
}

#[tauri::command(rename_all = "camelCase")]
pub async fn register_repository(
    path: String,
    state: State<'_, AppState>,
    proxy: State<'_, SidecarProxy>,
) -> Result<Repository, String> {
    let payload = json!({ "path": path });

    proxy
        .post(&state, "/v1/repositories/register", &payload)
        .await
}

#[tauri::command(rename_all = "camelCase")]
pub async fn initialise_and_register_repository(
    path: String,
    state: State<'_, AppState>,
    proxy: State<'_, SidecarProxy>,
) -> Result<Repository, String> {
    // This command is called only after the React confirmation dialog is
    // accepted. The backend re-classifies the folder again before git init.
    let payload = json!({
        "path": path,
        "confirmed": true,
    });

    proxy
        .post(
            &state,
            "/v1/repositories/initialise-and-register",
            &payload,
        )
        .await
}


// #[tauri::command(rename_all = "camelCase")]
// pub async fn pick_and_register_repository(
//     app: AppHandle,
//     state: State<'_, AppState>,
//     proxy: State<'_, SidecarProxy>,
// ) -> Result<Option<Repository>, String> {
//     let selected = app.dialog().file().blocking_pick_folder();
//     let Some(selected) = selected else {
//         return Ok(None);
//     };

//     let path = match selected {
//         FilePath::Path(path) => path,
//         FilePath::Url(_) => return Err("The selected folder must be a local filesystem path.".to_owned()),
//     };

//     let payload = json!({ "path": path.to_string_lossy() });
//     proxy.post(&state, "/v1/repositories/register", &payload).await.map(Some)
// }

#[tauri::command(rename_all = "camelCase")]
pub async fn get_repository_snapshot(
    repository_id: String,
    state: State<'_, AppState>,
    proxy: State<'_, SidecarProxy>,
) -> Result<RepositorySnapshot, String> {
    proxy
        .get(&state, &format!("/v1/repositories/{repository_id}/snapshot"))
        .await
}

#[tauri::command(rename_all = "camelCase")]
pub async fn run_read_action(
    repository_id: String,
    request: ReadActionRequest,
    state: State<'_, AppState>,
    proxy: State<'_, SidecarProxy>,
) -> Result<ReadActionResult, String> {
    proxy
        .post(
            &state,
            &format!("/v1/repositories/{repository_id}/read-actions"),
            &request,
        )
        .await
}

#[tauri::command(rename_all = "camelCase")]
pub async fn resolve_local_request(
    repository_id: String,
    message: String,
    state: State<'_, AppState>,
    proxy: State<'_, SidecarProxy>,
) -> Result<LocalResolution, String> {
    let payload = json!({ "message": message });
    proxy
        .post(
            &state,
            &format!("/v1/repositories/{repository_id}/resolve-local"),
            &payload,
        )
        .await
}
