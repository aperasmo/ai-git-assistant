from __future__ import annotations

from fastapi import APIRouter, Depends, Request

from app.auth import require_session_token
from app.schemas.repositories import (
    LocalResolution,
    LocalResolveRequest,
    ReadActionRequest,
    ReadActionResult,
    RegisterRepositoryRequest,
    RepositoryResponse,
    RepositorySnapshot,
    FolderClassificationResponse,
    InitialiseAndRegisterRequest,
)

router = APIRouter(prefix="/v1/repositories", tags=["repositories"])


def _service(request: Request):
    return request.app.state.repository_service

@router.post(
    "/classify",
    response_model=FolderClassificationResponse,
    dependencies=[Depends(require_session_token)],
)
def classify_repository_folder(
    payload: RegisterRepositoryRequest,
    request: Request,
) -> FolderClassificationResponse:
    return _service(request).classify_selected_folder(payload.path)

@router.post(
    "/initialise-and-register",
    response_model=RepositoryResponse,
    dependencies=[Depends(require_session_token)],
)
def initialise_and_register_repository(
    payload: InitialiseAndRegisterRequest,
    request: Request,
) -> RepositoryResponse:
    return _service(request).initialise_and_register(payload.path)

@router.post(
    "/register",
    response_model=RepositoryResponse,
    dependencies=[Depends(require_session_token)],
)
def register_repository(
    payload: RegisterRepositoryRequest,
    request: Request,
) -> RepositoryResponse:
    return _service(request).register(payload.path)


@router.get(
    "",
    response_model=list[RepositoryResponse],
    dependencies=[Depends(require_session_token)],
)
def list_repositories(request: Request) -> list[RepositoryResponse]:
    return _service(request).list()


@router.get(
    "/{repository_id}/snapshot",
    response_model=RepositorySnapshot,
    dependencies=[Depends(require_session_token)],
)
def repository_snapshot(repository_id: str, request: Request) -> RepositorySnapshot:
    return _service(request).snapshot(repository_id)


@router.post(
    "/{repository_id}/read-actions",
    response_model=ReadActionResult,
    dependencies=[Depends(require_session_token)],
)
def run_read_action(
    repository_id: str,
    payload: ReadActionRequest,
    request: Request,
) -> ReadActionResult:
    return _service(request).run_read_action(repository_id, payload)


@router.post(
    "/{repository_id}/resolve-local",
    response_model=LocalResolution,
    dependencies=[Depends(require_session_token)],
)
def resolve_local(
    repository_id: str,
    payload: LocalResolveRequest,
    request: Request,
) -> LocalResolution:
    _ = repository_id
    return _service(request).resolve_local(payload.message)
