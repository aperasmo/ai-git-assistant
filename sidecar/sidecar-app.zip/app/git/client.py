from __future__ import annotations

import os
import subprocess
from collections.abc import Sequence
from dataclasses import dataclass
from pathlib import Path

from app.errors import GitCommandError


@dataclass(frozen=True)
class GitResult:
    stdout: str
    stderr: str
    return_code: int


class GitClient:
    def __init__(self, repository_path: Path | None = None) -> None:
        self.repository_path = repository_path

    def run(
        self,
        args: Sequence[str],
        *,
        timeout_seconds: int = 20,
        allow_failure: bool = False,
    ) -> GitResult:
        command = ["git", *args]
        environment = os.environ.copy()
        environment.update(
            {
                "GIT_TERMINAL_PROMPT": "0",
                "GIT_PAGER": "cat",
                "PAGER": "cat",
                "LC_ALL": "C",
            }
        )

        try:
            completed = subprocess.run(
                command,
                cwd=str(self.repository_path) if self.repository_path else None,
                shell=False,
                check=False,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=timeout_seconds,
                env=environment,
            )
        except FileNotFoundError as exc:
            raise GitCommandError("Git was not found on PATH.", status_code=503) from exc
        except subprocess.TimeoutExpired as exc:
            raise GitCommandError("Git command timed out.") from exc

        result = GitResult(
            stdout=completed.stdout,
            stderr=completed.stderr,
            return_code=completed.returncode,
        )

        if completed.returncode != 0 and not allow_failure:
            raise GitCommandError(self._safe_error(result))

        return result

    @staticmethod
    def _safe_error(result: GitResult) -> str:
        raw = (result.stderr or result.stdout or "Git command failed.").strip()
        first_line = raw.splitlines()[0] if raw else "Git command failed."
        return first_line[:500]

    def version(self) -> str:
        return self.run(["--version"]).stdout.strip()

    def rev_parse(self, argument: str) -> str:
        return self.run(["rev-parse", argument]).stdout.strip()

    def initialise_repository(self, initial_branch: str) -> GitResult:
        # Repository creation is an explicit write operation. Keep it inside the
        # Git client so it uses the same non-interactive, argument-array execution
        # boundary as every other Git command in the application.
        return self.run(["init", "-b", initial_branch])

    def status_porcelain_v1_z(self) -> str:
        return self.run(["status", "--porcelain=v1", "--untracked-files=all", "-z"]).stdout

    def status_porcelain_v2_branch(self) -> str:
        return self.run(["status", "--porcelain=v2", "--branch", "--untracked-files=all"]).stdout

    def log(self, limit: int) -> str:
        bounded_limit = max(1, min(limit, 50))
        return self.run(
            [
                "log",
                f"-n{bounded_limit}",
                "--format=%H%x1f%h%x1f%an%x1f%aI%x1f%s%x1e",
            ]
        ).stdout

    def branch_list(self) -> str:
        # Git ref-filter formatting uses %09 for a literal tab. One branch is
        # emitted per line, allowing the service to preserve the HEAD marker.
        return self.run(
            ["branch", "--format=%(HEAD)%09%(refname:short)%09%(upstream:short)"]
        ).stdout

    def diff_stat(self, scope: str = "all") -> str:
        if scope == "staged":
            arguments = ["diff", "--cached", "--no-ext-diff", "--stat"]
        elif scope == "unstaged":
            arguments = ["diff", "--no-ext-diff", "--stat"]
        else:
            arguments = ["diff", "HEAD", "--no-ext-diff", "--stat"]
        return self.run(arguments).stdout

    def fetch_prune(self) -> GitResult:
        return self.run(["fetch", "--prune"], timeout_seconds=45)
