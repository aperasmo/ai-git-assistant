from __future__ import annotations

import re

from app.schemas.repositories import LocalResolution, ReadAction


class LocalIntentMatcher:
    def resolve(self, message: str) -> LocalResolution:
        text = " ".join(message.lower().strip().split())

        if text in {"status", "git status", "what changed", "what's changed", "whats changed"}:
            return LocalResolution(
                matched=True,
                action=ReadAction.STATUS,
                explanation="Resolved locally as Git status.",
            )

        if "refresh remote" in text or "fetch" in text or "update remote status" in text:
            return LocalResolution(
                matched=True,
                action=ReadAction.FETCH,
                explanation="Resolved locally as an explicit remote refresh.",
            )

        if "branch" in text and any(token in text for token in ("show", "list", "what", "which")):
            return LocalResolution(
                matched=True,
                action=ReadAction.BRANCHES,
                explanation="Resolved locally as branch listing.",
            )

        if "diff" in text or "difference" in text:
            return LocalResolution(
                matched=True,
                action=ReadAction.DIFF,
                explanation="Resolved locally as a bounded diff summary.",
            )

        commits_match = re.search(r"(?:last|recent)\s+(\d{1,2})\s+commits?", text)
        if commits_match or text in {"log", "git log", "show commits", "recent commits"}:
            limit = int(commits_match.group(1)) if commits_match else 5
            return LocalResolution(
                matched=True,
                action=ReadAction.LOG,
                params={"limit": max(1, min(limit, 50))},
                explanation="Resolved locally as recent commit history.",
            )

        return LocalResolution(
            matched=False,
            explanation="No supported local read action matched this request.",
        )
