from __future__ import annotations

from datetime import UTC, datetime

from app.errors import GitCommandError, ValidationFailure
from app.git.client import GitClient
from app.git.repository_inspector import RepositoryInspector
from app.intent.local_matcher import LocalIntentMatcher
from app.schemas.repositories import (
    BranchInfo,
    FolderClassificationResponse,
    LocalResolution,
    ReadAction,
    ReadActionRequest,
    ReadActionResult,
    RecentCommit,
    RepositoryResponse,
    RepositorySnapshot,    
)
from app.services.repository_store import RepositoryStore
from app.config import Settings

from app.errors import ValidationFailure
from app.git.client import GitClient

class RepositoryService:
    def __init__(
        self,
        store: RepositoryStore,
        inspector: RepositoryInspector,
        matcher: LocalIntentMatcher,
        settings: Settings,
    ) -> None:
        self.store = store
        self.inspector = inspector
        self.matcher = matcher
        self.settings = settings

    def classify_selected_folder(
        self,
        selected_path: str,
    ) -> FolderClassificationResponse:
        classification = self.inspector.classify_selected_folder(selected_path)

        # The inspector owns filesystem and Git probing. The service maps that
        # internal result into the stable response contract used by the API/UI.
        return FolderClassificationResponse(
            kind=classification.kind,
            selected_path=str(classification.selected_path),
            repository_root=(
                str(classification.repository_root)
                if classification.repository_root is not None
                else None
            ),
            can_initialise=classification.can_initialise,
            message=classification.message,
        )

    def initialise_and_register(self, selected_path: str) -> RepositoryResponse:
        # Re-check immediately before writing. A folder can change after the UI
        # classified it, so only a known plain folder may be initialised.
        classification = self.inspector.classify_selected_folder(selected_path)

        if classification.kind != "initialisation_required":
            raise ValidationFailure(
                "This folder cannot be initialised because it is no longer a plain "
                "non-Git folder."
            )

        client = GitClient(classification.selected_path)
        client.initialise_repository(self.settings.initial_branch)

        # Register through the existing strict validation path so newly created
        # repositories receive the same safety checks as existing repositories.
        return self.register(str(classification.selected_path))

    def register(self, selected_path: str) -> RepositoryResponse:
        canonical_path = self.inspector.canonicalise_and_validate(selected_path)
        provisional = self.store.upsert(canonical_path, current_branch=None)
        snapshot = self.snapshot(provisional.id)
        return self.store.upsert(canonical_path, current_branch=snapshot.branch)

    def list(self) -> list[RepositoryResponse]:
        return self.store.list()

    def snapshot(self, repository_id: str) -> RepositorySnapshot:
        repository = self.store.get(repository_id)
        canonical_path = self.store.canonical_path(repository_id)
        inspection = self.inspector.inspect(
            repository_id,
            canonical_path,
            remote_last_refreshed_at=repository.last_remote_refresh_at,
        )
        snapshot = inspection.snapshot.model_copy(
            update={"recent_commits": self._recent_commits(canonical_path)}
        )
        self.store.update_inspection(repository_id, branch=snapshot.branch)
        return snapshot

    def resolve_local(self, message: str) -> LocalResolution:
        return self.matcher.resolve(message)

    def run_read_action(
        self,
        repository_id: str,
        request: ReadActionRequest,
    ) -> ReadActionResult:
        canonical_path = self.store.canonical_path(repository_id)
        client = GitClient(canonical_path)

        if request.action is ReadAction.STATUS:
            snapshot = self.snapshot(repository_id)
            content = self._render_status(snapshot)
            return ReadActionResult(
                action=request.action,
                title="Git Status",
                summary="Live repository state was inspected locally.",
                content=content,
                snapshot=snapshot,
            )

        if request.action is ReadAction.LOG:
            limit = self._bounded_limit(request.params.get("limit", 5))
            snapshot = self.snapshot(repository_id)
            content = self._render_log(client.log(limit))
            return ReadActionResult(
                action=request.action,
                title=f"Last {limit} commits",
                summary="Commit history was read locally and bounded to the requested limit.",
                content=content or "No commits found.",
                snapshot=snapshot,
            )

        if request.action is ReadAction.DIFF:
            scope = str(request.params.get("scope", "all"))
            if scope not in {"all", "staged", "unstaged"}:
                raise ValidationFailure("Diff scope must be all, staged, or unstaged.")
            snapshot = self.snapshot(repository_id)
            content = client.diff_stat(scope).strip()
            return ReadActionResult(
                action=request.action,
                title="Diff Summary",
                summary="Only Git's bounded stat summary is shown in this foundation build.",
                content=content or "No differences in the selected scope.",
                snapshot=snapshot,
            )

        if request.action is ReadAction.BRANCHES:
            snapshot = self.snapshot(repository_id)
            content = self._render_branches(client.branch_list())
            return ReadActionResult(
                action=request.action,
                title="Local Branches",
                summary="Local branch names were read without switching branches.",
                content=content or "No local branches found.",
                snapshot=snapshot,
            )

        if request.action is ReadAction.FETCH:
            client.fetch_prune()
            refreshed_at = datetime.now(UTC).isoformat()
            pre_snapshot = self.snapshot(repository_id)
            self.store.update_inspection(
                repository_id,
                branch=pre_snapshot.branch,
                remote_last_refreshed_at=refreshed_at,
                update_remote_refresh=True,
            )
            snapshot = self.snapshot(repository_id)
            return ReadActionResult(
                action=request.action,
                title="Remote Status Refreshed",
                summary=(
                    "Remote tracking references were refreshed explicitly with git fetch --prune."
                ),
                content=(
                    f"Remote refresh completed.\nAhead: {snapshot.ahead}\nBehind: {snapshot.behind}"
                ),
                snapshot=snapshot,
            )

        raise ValidationFailure("Unsupported read action.")

    @staticmethod
    def _bounded_limit(value: object) -> int:
        try:
            parsed = int(value)
        except (TypeError, ValueError) as exc:
            raise ValidationFailure("Log limit must be a number.") from exc
        return max(1, min(parsed, 50))

    @staticmethod
    def _recent_commits(canonical_path) -> list[RecentCommit]:
        try:
            raw = GitClient(canonical_path).log(4)
        except GitCommandError:
            return []

        commits: list[RecentCommit] = []
        for record in raw.split("\x1e"):
            fields = record.strip().split("\x1f")
            if len(fields) != 5:
                continue
            commits.append(
                RecentCommit(
                    full_hash=fields[0],
                    short_hash=fields[1],
                    author=fields[2],
                    committed_at=fields[3],
                    subject=fields[4],
                )
            )
        return commits

    @staticmethod
    def _render_status(snapshot: RepositorySnapshot) -> str:
        lines = [
            f"Branch: {snapshot.branch or 'Detached HEAD'}",
            f"HEAD: {snapshot.head_commit or 'No commit yet'}",
            f"Staged: {len(snapshot.staged_changes)}",
            f"Modified: {len(snapshot.modified_changes)}",
            f"Untracked: {len(snapshot.untracked_paths)}",
            f"Conflicts: {len(snapshot.conflicts)}",
            f"Ahead: {snapshot.ahead}",
            f"Behind: {snapshot.behind}",
        ]
        if snapshot.write_blocked_reason:
            lines.extend(["", f"Write actions blocked: {snapshot.write_blocked_reason}"])
        return "\n".join(lines)

    @staticmethod
    def _render_log(raw: str) -> str:
        lines: list[str] = []
        for record in raw.split("\x1e"):
            fields = record.strip().split("\x1f")
            if len(fields) != 5:
                continue
            _, short_hash, author, committed_at, subject = fields
            lines.append(f"{short_hash}  {subject}\n  {author} · {committed_at}")
        return "\n".join(lines)

    @staticmethod
    def _render_branches(raw: str) -> str:
        branches: list[BranchInfo] = []

        for line in raw.splitlines():
            if not line:
                continue

            fields = line.split("\t", 2)
            if len(fields) < 2:
                continue

            head_marker, name = fields[0], fields[1]
            upstream = fields[2] if len(fields) > 2 and fields[2] else None

            branches.append(
                BranchInfo(
                    name=name,
                    is_current=head_marker == "*",
                    upstream=upstream,
                )
            )

        return "\n".join(
            f"{'*' if branch.is_current else ' '} {branch.name}"
            + (f"  → {branch.upstream}" if branch.upstream else "")
            for branch in branches
        )
